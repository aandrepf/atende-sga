/////// CONFIG TEMPLATE ////


///////////////// START CONFIG /////////////////

var BASE_URL;
var suffix;

var ATENDIMENTO;
var USER;
var UTIL;
var AGENCIA;

var DEBUG = 0;

print('V 1.0.41');

if(DEBUG == 2){
    BASE_URL    = 'json/';
    suffix      = '.json';
}else if(DEBUG == 1){
    BASE_URL    = location.protocol + '//' + location.host + ':8080/';
    suffix      = '';
}else{
    BASE_URL    = location.protocol + '//' + location.host + '/';
    suffix      = '';
}

ATENDIMENTO = BASE_URL+'atendimento/';
USER        = BASE_URL+'ws/us/';
UTIL        = BASE_URL+'utils/';
AGENCIA     = BASE_URL+'agencia/';


// Reativar Rechamar
var contadorRechamar;
var tempoReativar   = 2000; // 2s

// Timer Atendimento
var contadorAtendimento;
var segsAtend = 0;

// Timer Atendimento
var contadorSuspensao;
var segsSusp = 0;

// Chamada Busca Atendimento Pendente
var contadorBusca;
var tempoBusca      = 15000; // 30s

// Tempos das Páginas de Monitoramento
var contadorCategorias;
var tempoCategorias = 15000;
var contadorSenhas;
var tempoSenhas     = 60000;
var contadorCaixas;
var tempoCaixas     = 60000;

///////////////// END CONFIG /////////////////

var lastAction;
var currentUser;
var idAtendimento;
var catAtendimento;
var emAtendimento = false;
var labelSuspensao = '';
var usaLocucao = 'N';
var senhaAtual;

var bt_ativos   = [];

var today = new Date();
var dd = today.getDate();

var mm = today.getMonth()+1; 
var yyyy = today.getFullYear();
if(dd<10){
    dd='0'+dd;
}
if(mm<10){
    mm='0'+mm;
} 
var hoje = dd+'/'+mm+'/'+yyyy;

window.onbeforeunload = function(){
    if(currentUser != undefined){
        return 'Você precisa fazer logout antes de fechar esta janela.';
    }
}

$(function () {
    
    print(currentUser);
    
    if (currentUser === undefined || currentUser === null) {
        
        $('#main .main_content').load('content/home.html', function(){
            
            $('#login').submit(function(){
                
                if($('#matricula').val()==''){
                    showMessage('Informe a matrícula');
                    return false;
                }
                    
                $('#login').append('<div class="overlay" style="position:absolute; width:100%;height: 100%; top:0;left:0; background:#FAFAFA; display:none;"></div>');//css({'opacity':.6});
                $('#login .overlay').fadeTo( "fast", 0.5 );

                var formData = {
                    "hostname"  : $('#matricula').val().toUpperCase(),
                    "matricula" : $('#matricula').val().toUpperCase()
                };
                
                
                $.ajax({
                    type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                    url			: USER+'login'+suffix, // the url where we want to POST
                    contentType : 'application/json',
                    data		: JSON.stringify(formData), // our data object
                    dataType	: 'json', // what type of data do we expect back from the server
                    encode		: true
                }).done(function(data) {
                        
                    print(data);
                    if(data.usuarioID>0){

                        currentUser = data;

                        if(currentUser.usuarioTipo == 1){
                            $('.monitor_only').css({'display':'none'})
                        }

                        $('#nome_atendente').text(currentUser.usuarioNome);

                        print(currentUser);
                        loadAtendimento();

                    }else if(data.error.indexOf('EMISSOR NÃO ENCONTRADO') != -1){
                             
                        //showForceLogoff($('#matricula').val());
                        showMessage(data.error);
                             
                    }else{

                        showForceLogoff($('#matricula').val());
                        showMessage(data.error);

                    }
                    $('#login .overlay').fadeOut( "fast" );

                });

                return false;

            });
            
        });
        
    }else{
        if(currentUser.usuarioID !== ''){
            $('#nome_atendente').text(currentUser.usuarioNome);
            loadAtendimento();
            //return false;
        }
    }
    
    $('#bt_atender').click(function(e){
        e.preventDefault();
        
        closeMenuRetratil();
        loadAtendimento();
        setarMenu($(this));
    });
    
    $('#bt_monitor').click(function(e){
        e.preventDefault();
        
        closeMenuRetratil();
        loadMonitor();
        setarMenu($(this));
    });
    
    $('#bt_configuracoes').click(function(e){
        e.preventDefault();
        
        closeMenuRetratil();
        loadConfiguracoes();
        setarMenu($(this));
    });
    
    $('.bt_menu_retratil').click(function(e){
        e.preventDefault();
        
        if(!emAtendimento){
            openMenuRetratil();
        }else{
            showMessage('Você só pode acessar este menu enquanto não estiver em atendimento.');
        }
    });
    
    $('.close').click(function(e){
        e.preventDefault();
        
        closeMenuRetratil()
    });
    
    $('.modal .closebtn').click(function(e){
        e.preventDefault();
        
        closeModal();
    });
    
    $('#bt_logoff').click(function(e){
        e.preventDefault();
        
        logOff();
    });
    
});


function showForceLogoff(matricula) {
    
    print(matricula);
    
    $('.modal .modal_content').load('modal/force-logoff.html', function(){
        
        $('#cancelar').click(function(e){
            $('#login .overlay').fadeOut( "fast" );
            e.preventDefault();
            closeModal();
        });
        
        $('form').submit(function(e){
            e.preventDefault();
            var formData = {
                'matricula' : matricula,
                'hostname'  : matricula
            };

            $.ajax({
                type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url			: USER+'logoff'+suffix, // the url where we want to POST
                contentType : 'application/json',
                data		: JSON.stringify(formData), // our data object
                dataType	: 'json', // what type of data do we expect back from the server
                encode		: true
            }).done(function(data) {

                if(data.logoff == true){

                    var formData = {
                        "hostname"  : matricula,
                        "matricula" : matricula
                    };


                    $.ajax({
                        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url			: USER+'login'+suffix, // the url where we want to POST
                        contentType : 'application/json',
                        data		: JSON.stringify(formData), // our data object
                        dataType	: 'json', // what type of data do we expect back from the server
                        encode		: true
                    }).done(function(data) {

                        if(data.usuarioID>0){

                            currentUser = data;

                            if(currentUser.usuarioTipo == 1){
                                $('.monitor_only').css({'display':'none'})
                            }

                            $('#nome_atendente').text(currentUser.usuarioNome);
                            $('#login .overlay').fadeOut( "fast" );

                            print(currentUser);
                            closeModal();
                            
                            loadAtendimento();

                        }else{

                            showMessage(data.error);

                        }


                    });
                    
                }

            });
        });
        
    }, $('.modal').fadeIn());
}


function setarMenu(menu_item){
    $('.menu_retratil ul li').removeClass('active');
    $(menu_item).parent().addClass('active');
}

function openMenuRetratil(){
    $('.menu_retratil').stop().animate({
                        marginLeft: '0'
                    }, 500, "linear");
}

function closeMenuRetratil(){
    $('.menu_retratil').stop().animate({
                        marginLeft: '-200px'
                    }, 200, "linear");
}

function showMessage(msg){
    
    $('#system_messages .content_message').text(msg);
    $('#system_messages').animate({
        marginBottom: '20px'
    }, 100, "linear", function() {
        $('#system_messages').delay(2000).animate({
            marginBottom: '-200px'
        }, 100, "linear");
    });
    
} 

function logOff(){
    
    var formData = {
        'matricula' : currentUser.usuarioID,
        'hostname'  : currentUser.usuarioID
    };

    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: USER+'logoff'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {

        if(data.logoff == true){
            
            contagemBuscaStop();
            hideBarsMenu();
            $('#footer').css({'display':'none'});
			$('.menu_retratil').css({'margin-left':'-100%'});
            window.location = 'index.html';
        }

    });
}

function showFalhaEmissor(msg){
    $('#falha_emissor').text(msg);
    $('#falha_emissor').css({'display':'block'});
    $('#footer').css({'display':'none'});
}
function hideFalhaEmissor(){
    $('#footer').css({'display':'block'});
    $('#falha_emissor').css({'display':'none'});
}

function busca(){
    
    var formData = {
        'id'            : currentUser.emissorID,
        'token'         : currentUser.emissorToken,
        'tipoRetorno'   : "1"
    };
    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: USER+'busca'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {

        //print(data);
        if(data.error){
            showFalhaEmissor(data.error);
            
        }else if(data.senhas.length>0){
            hideFalhaEmissor();
            
            var date = new Date();
            print('buscando: '+date.getHours()+':'+date.getMinutes()+':'+date.getSeconds());
            //print(currentUser.politica);
            print(data);
            
            // Atualiza política do atendente se esta mudou
            if($('.politica_value').text() != data.politicaFormatada){
                
                $('.politica_value').text(data.politicaFormatada);
                print('Política mudou');
                
            }
            
            //print(currentUser.politica);
            
            var fila = [];
            var cats_fila = [];
            var total_agencia = 0;
            var qt_senhas = data.senhas.length;
            for(var i = 0; i<qt_senhas; i++){
                if(data.senhas[i]['total']>0){
                    fila = [data.senhas[i]['idCategoria'], data.senhas[i]['total']];
                    //print(fila);
                    cats_fila.push(fila);
                    total_agencia = total_agencia+data.senhas[i]['total'];
                }
            }
            $('.espera_agencia .count').html(total_agencia);
            print(cats_fila);
            
            
            var arrPolitica = [];
            var qt_politica = data.politica.length;
            for(var p = 0; p<qt_politica; p++){
                arrPolitica.push(data.politica[p].categoria.id);
            }
            print(arrPolitica);
            
            // Total atendimento para este usuário
            var total_atendente = 0;
            
            var qt_fila = cats_fila.length;
            var qt_poli = arrPolitica.length;
            for(var f = 0; f<qt_fila; f++){
                
                var cat = cats_fila[f];
                
                for(var p2 = 0; p2 < qt_poli; p2++){
                    var pol = arrPolitica[p2];
                    
                    //print(cat[0] + ' == ' + pol);
                    if(cat[0] == pol){
                        total_atendente += cat[1];
                    }
                    
                }
                
            }
            $('.espera_atendente .count').html(total_atendente);
            
            if(lastAction == 'descancelar'){
                ativar('bt_chamar_voz, bt_rechamar, bt_iniciar_atendimento, bt_cancelar');
                //print('--->>> busca bt_rechamar');
                
            }else if(lastAction == 'cancelar'){
                ativar('bt_chamar_voz, bt_chamar, bt_descancelar, bt_suspender');
                
            }else if( (total_atendente>0) && emAtendimento == false){
                ativar('bt_chamar_voz, bt_chamar, bt_suspender');
                
            }else if( (total_atendente == 0) && emAtendimento == false){
                ativar('bt_suspender');
                //print('Nenhum senha para este atendente. Atendente em espera. Botões desativados.');
                
            }
            
        }else{
            //showMessage('Nenhuma senha registrada na agência.');
            desativar();
        }

    }).fail(function() {
        showFalhaEmissor('Falha na comunicação com o emissor.');
    });
}
// Auto Update Busca
function contagemBuscaStart(){
    //print('--->>> busca iniciou');
    contadorBusca = setInterval(busca, tempoBusca);
}
function contagemBuscaStop(){
    //print('--->>> busca parou');
    clearInterval(contadorBusca);
}

// Auto Update Categorias
function contagemCategoriasStart(){
    contadorCategorias = setInterval(reloadCategoriasList, tempoCategorias);
}
function contagemCategoriasStop(){
    clearInterval(contadorCategorias);
}

// Ativa/Desativa Rechamar
function desativaRechamar(){
    contadorRechamar = setInterval(reativarRechamar, tempoReativar);
}
function reativaRechamar(){
    clearInterval(contadorRechamar);
}
function reativarRechamar(){
    ativar('bt_chamar_voz, bt_rechamar, bt_iniciar_atendimento, bt_cancelar');
    //print('--->>> AQUI bt_rechamar');
    reativaRechamar();
}

// Auto Update Senhas
function contagemSenhasStart(){
    contadorSenhas = setInterval(reloadSenhasList, tempoSenhas);
}
function contagemSenhasStop(){
    clearInterval(contadorSenhas);
}

// Auto Update Caixas
function contagemCaixasStart(){
    contadorCaixas = setInterval(reloadCaixasList, tempoCaixas);
}
function contagemCaixasStop(){
    clearInterval(contadorCaixas);
}

function ativar(botoes){
    
    // Desativa tudo
    desativar();
    
    bt_ativos = [];
    
    var i = 0;
    var bts = botoes.split(',');
    var qt  = bts.length;
    for(i=0; i<qt; i++){
        var botao = $.trim(bts[i]);
        //print(botao);
        
        $('#'+botao).removeClass('disabled');
        //$('#'+botao).prop('disabled', false);
        
        if(botao == 'bt_descancelar'){
            $('#bt_cancelar').css({'display':'none'});
            $('#bt_descancelar').css({'display':'block'});
        }else if(botao == 'bt_cancelar'){
            $('#bt_cancelar').css({'display':'block'});
            $('#bt_descancelar').css({'display':'none'});
        }
        
        bt_ativos.push(botao);
        
    }
    //print(bt_ativos);
    
}
function desativar(){
    $('.menu_atendimento a').addClass('disabled');
}

function closeModal(){
    $('.modal').fadeOut();
}

function showBarsMenu(){
    $('.bt_menu_retratil').fadeIn(); //.addClass('logado');//.fadeIn();//.css({'display':'inline-block', 'padding-right':'10px'});
}
function hideBarsMenu(){
    $('.bt_menu_retratil').fadeOut(); //.removeClass('logado');//.fadeOut();//.css({'display':'none'});
}

function loadSuspenso(){
    
    hideBarsMenu();
    $('#footer').css({'display':'none'});
    $('#main .main_content').load('content/suspenso.html', function(){
        
        $('#motivo_suspensao').text(labelSuspensao);
        contagemSuspensaoStart();
        
        function formatatempo(segs) {
            var min = 0;
            var hr  = 0;
            while(segs>=60) {
                if (segs >=60) {
                    segs = segs-60;
                    min = min+1;
                }
            }
            while(min>=60) {
                if (min >=60) {
                    min = min-60;
                    hr = hr+1;
                }
            }

            if (hr < 10) {hr = "0"+hr}
            if (min < 10) {min = "0"+min}
            if (segs < 10) {segs = "0"+segs}
            var fin = hr+":"+min+":"+segs
            return fin;
        }
        function contagemSusp(){
            segsSusp++;
            var t = formatatempo(segsSusp);
            $("#contadorSuspensao").html(t);
        }
        function contagemSuspensaoStart(){
            contadorSuspensao = setInterval(contagemSusp, 1000);
        }
        function contagemSuspensaoStop(){
            segsSusp = 0;
            $("#contadorSuspensao").html('00:00:00');
            clearInterval(contadorSuspensao);
        }
        
        
        $('#bt_retornar').click(function(e){
            e.preventDefault();
            
            var formData = {
                'idUsuario'     : currentUser.usuarioID,
                'token'         : currentUser.emissorToken,
                'idCaixa'       : currentUser.emissorID
            };

            $.ajax({
                type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url			: USER+'retorno'+suffix, // the url where we want to POST
                contentType : 'application/json',
                data		: JSON.stringify(formData), // our data object
                dataType	: 'json', // what type of data do we expect back from the server
                encode		: true
            }).done(function(data) {

                //print(data);
                if(data.status==true){
                    
                    emAtendimento = false;
                    contagemSuspensaoStop();
                    loadAtendimento();
                    
                }

            });
            
        });
        
        
    });
    
}

function loadAtendimento(){
    
    //print(currentUser.politica);
    
    contagemCategoriasStop();
    contagemSenhasStop();
    contagemCaixasStop();

    showBarsMenu();
    emAtendimento = false;
    $('#footer').css({'display':'block'});
    $('#main .main_content').load('content/atendimento.html', function(){
        
        // Inicia desativado por padrão
        desativar();
        
        $('.posicao_value').text(currentUser.aliasCaixa);    
        $('.hostname_value').text(currentUser.hostname);
        $('.matricula_value').text(currentUser.usuarioID);
        $('.politica_value').text(currentUser.politicaFormatada);
        
        $('.card_terminal').css({'display':'inline-block'});
        
        // Inicia a busca por senhas
        busca();
        contagemBuscaStart();
        
        $('#bt_chamar_voz').click(function(e){
            e.preventDefault();
            
            if($.inArray( 'bt_chamar_voz' , bt_ativos ) !== -1){
                //print('#bt_chamar_voz');
                atendimentoChamarVoz();
            }
            
        });
        
        /*$('#bt_urgencia').click(function(e){
            e.preventDefault();
            
            if($.inArray( $(this) , bt_ativos )>0){
                atendimentoNovaSenha();
            }
            
        });*/
        
        $('#bt_chamar').click(function(e){
            e.preventDefault();
            
            if($.inArray( $(this).attr('id') , bt_ativos ) !== -1){
                //print('#bt_chamar');
                closeMenuRetratil();
                atendimentoChamar();
            }            
            
        });
        
        $('#bt_rechamar').click(function(e){
            e.preventDefault();
            
            if($.inArray( $(this).attr('id') , bt_ativos ) !== -1){
                
                //print('#bt_rechamar');
                closeMenuRetratil();
                atendimentoReChamar();
            }
            
        });
        
        $('#bt_iniciar_atendimento').click(function(e){
            e.preventDefault();
            
            if($.inArray( $(this).attr('id') , bt_ativos ) !== -1){
                //print('#bt_iniciar_atendimento');
                closeMenuRetratil();
                atendimentoIniciarAtendimento();
            }
            
        });
        
        $('#bt_redirecionar').click(function(e){
            e.preventDefault();
            
            if($.inArray( $(this).attr('id') , bt_ativos ) !== -1){
                //print('#bt_redirecionar');
                closeMenuRetratil();
                promptRedirecionar();
            }
            
        });
        
        $('#bt_cancelar').click(function(e){
            e.preventDefault();
            
            if($.inArray( $(this).attr('id') , bt_ativos ) !== -1){
                //print('#bt_cancelar');
                closeMenuRetratil();
                atendimentoCancelar();
            }
            
        });
        
        $('#bt_descancelar').click(function(e){
            e.preventDefault();
            
            if($.inArray( $(this).attr('id') , bt_ativos ) !== -1){
                //print('#bt_descancelar');
                closeMenuRetratil();
                atendimentoDescancelar();
            }
            
        });
        
        $('#bt_finalizar').click(function(e){
            e.preventDefault();
            
            if($.inArray( $(this).attr('id') , bt_ativos ) !== -1){
                //print('#bt_finalizar');
                closeMenuRetratil();
                atendimentoFinalizar();
            }
            
        });
        
        $('#bt_suspender').click(function(e){
            e.preventDefault();
            
            if($.inArray( $(this).attr('id') , bt_ativos ) !== -1){
                //print('#bt_suspender');
                closeMenuRetratil();
                atendimentoSuspender();
            }
            
        });
    });
}

function openModalRedirecionar(data) {
    
    $('.modal .modal_content').load('modal/redirecionar.html', function(){
        
        var html_categorias = '';
        $.each(data, function() {
            $.each(this, function(k, v) {
                if(catAtendimento != v.idCategoria){
                    html_categorias += '<option value="'+v.idCategoria+'">'+v.nomeCategoria+'</option>';
                }
            });
        });
        //print(parametros);
        $('#redirecionar_categorias').html(html_categorias);
        $('#cancelar').click(function(e){
            e.preventDefault();
            closeModal();
        });
        
        $('form').submit(function(e){
            e.preventDefault();
            
            var idCategoria = $('#redirecionar_categorias').val();
            var priorizar   = ($('#redirecionar_priorizar').is(':checked')) ? true : false;
            var obs         = $('#redirecionar_obs').val();
            
            var formData = {};
            
            if(obs != ''){
                formData = {
                    "idUsuario"     : currentUser.usuarioID,
                    "idAtendimento" : idAtendimento,
                    "categoria"     : new Number(idCategoria),
                    "priorizar"     : priorizar,
                    "obs"           : obs
                };
            }else{
                formData = {
                    "idUsuario"     : currentUser.usuarioID,
                    "idAtendimento" : idAtendimento,
                    "categoria"     : new Number(idCategoria),
                    "priorizar"     : priorizar
                };
            }

            $.ajax({
                type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url			: ATENDIMENTO+'redirecionarSenha'+suffix, // the url where we want to POST
                contentType : 'application/json',
                data		: JSON.stringify(formData), // our data object
                dataType	: 'json', // what type of data do we expect back from the server
                encode		: true
            }).done(function(data) {

                //print(data);
                if(data.retorno == true){
                    
                    lastAction = 'redirecionar';
                    
                    showMessage('Senha '+senhaAtual+' redirecionada com sucesso.');
                    closeModal();
                    emAtendimento = false;
                    contagemAtendimentoStop();
                    loadAtendimento();
                    
                }
            }); 
        });
    }, $('.modal').fadeIn());
}

function openModalSuspender(data) {
    
    $('.modal .modal_content').load('modal/suspender.html', function(){
        
        var html_categorias = '';
        $.each(data, function() {
            $.each(this, function(k, v) {
                html_categorias += '<option value="'+v.id+'">'+v.descricao+'</option>';
            });
        });
        //print(parametros);
        $('#suspender_categorias').html(html_categorias);
        $('#cancelar').click(function(e){
            e.preventDefault();
            closeModal();
        });
        
        $('form').submit(function(e){
            e.preventDefault();
            
            var motivoSuspensao = $('#suspender_categorias').val();
            
            // Pra mostrar na tea de Suspensão
            labelSuspensao = $('#suspender_categorias option:selected').text();
            
            var formData = {
                'idUsuario'         : currentUser.usuarioID,
                'motivoSuspensao'   : motivoSuspensao
            };

            $.ajax({
                type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url			: USER+'suspender'+suffix, // the url where we want to POST
                contentType : 'application/json',
                data		: JSON.stringify(formData), // our data object
                dataType	: 'json', // what type of data do we expect back from the server
                encode		: true
            }).done(function(data) {

                if(data.status == true){
                    
                    lastAction = 'suspender';
                    closeModal();
                    emAtendimento = false;
                    contagemAtendimentoStop();
                    contagemBuscaStop();
                    loadSuspenso();
                    
                }

            });
            
        });
        
        
    });
    $('.modal').fadeIn();
    //$('.modal').css({'display':'inline-block', 'padding-right':'10px'});
}

function openModalFinalizar(data) {
    
    $('.modal .modal_content').load('modal/finalizar.html', function(){
        
        var html_categorias = '';
        $.each(data, function() {
            $.each(this, function(k, v) {
                html_categorias += '<option value="'+v.idObjetivo+'">'+v.objetivo+'</option>';
            });
        });
        //print(parametros);
        $('#finalizar_categorias').html(html_categorias);
        
        $('#cancelar').click(function(e){
            e.preventDefault();
            closeModal();
        });
        
        $('form').submit(function(e){
            e.preventDefault();
            
            var objetivoAtendimento = $('#finalizar_categorias').val();
            
            var formData = {
                'idUsuario'     : currentUser.usuarioID,
                'token'         : currentUser.emissorToken,
                'idAtendimento' : idAtendimento,
                'objetivo'      : objetivoAtendimento
            };

            $.ajax({
                type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url			: ATENDIMENTO+'finalizarSenha'+suffix, // the url where we want to POST
                contentType : 'application/json',
                data		: JSON.stringify(formData), // our data object
                dataType	: 'json', // what type of data do we expect back from the server
                encode		: true
            }).done(function(data) {

                //print(data);
                if(data.idAtendimento>0){
                    
                    lastAction = 'finalizar';
                    closeModal();
                    emAtendimento = false;
                    contagemAtendimentoStop();
                    loadAtendimento();
                    
                }

            });
            
        });
        
        
    }, $('.modal').fadeIn());
    //$('.modal').css({'display':'inline-block', 'padding-right':'10px'});
}

function loadMonitor(){
    
    showBarsMenu();
    $('#footer').css({'display':'none'});
    //$('#nome_atendente').text(currentUser.usuarioNome);
    
    contagemBuscaStop();
    getMonitoramentoCategoria();
    contagemCategoriasStart();
    
}

function getMonitoramentoCategoria(){
    
    contagemSenhasStop();
    contagemCaixasStop();
    
    $('#main .main_content').load('content/monitor-categorias.html', function(){
        
        $('.view_categorias_filas').click(function(e){
            e.preventDefault();

            //getMonitoramentoCategoria();
        });

        $('.view_historico_senhas').click(function(e){
            e.preventDefault();

            getMonitoramentoSenhas();
            contagemSenhasStart();
        });

        $('.view_historico_caixas').click(function(e){
            e.preventDefault();

            getMonitoramentoCaixas();
            contagemCaixasStart();
        });
    
        var date = new Date();
        //print('monitoramento Categoria atualizado: '+date.getHours()+':'+date.getMinutes()+':'+date.getSeconds());

        var formData = {};

        $.ajax({
            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url			: UTIL+'getMonitoramentoCategoria'+suffix, // the url where we want to POST
            contentType : 'application/json',
            data		: JSON.stringify(formData), // our data object
            dataType	: 'json', // what type of data do we expect back from the server
            encode		: true
        }).done(function(data) {

            //print(data);

            if(data){

                var item = '';

                $.each(data, function() {
                    $.each(this, function(k, v) {

                        var cor_item = '';

                        var bg_verde    = false;
                        var bg_amarelo  = false;
                        var bg_vermelho = false;

                        $.each(v.senhaEmAberto, function(k, v2) {

                            var meta    = (v2.porcMeta/v.metaDia)*100;
                            meta = parseFloat(Math.round(meta * 100) / 100).toFixed(2);

                            if(meta >= v.minVermelho){
                                bg_vermelho = true;
                            }else if(meta >= v.minAmarelo){
                                bg_amarelo = true;
                            }else{
                                bg_verde = true;
                            }

                        });

                        if(bg_verde == true){
                            print('bg_verde');
                            cor_item = 'bg_verde';
                        }
                        if(bg_amarelo == true){
                            print('bg_amarelo');
                            cor_item = 'bg_amarelo';
                        }
                        if(bg_vermelho == true){
                            print('bg_vermelho');
                            cor_item = 'bg_vermelho';
                        }

                        //html_categorias += '<option value="'+v.idCategoria+'">'+v.nomeCategoria+'</option>';
                        item += '<tr id="categoria'+v.idCategoria+'"><td class="align_left">'+v.nomeCategoria+'</td><td class="totalSenhaEmAberto">'+v.totalSenhaEmAberto+'</td><td class="status"><span class="bolinha '+cor_item+'"></span></td><td><a data-id="'+k+'" class="view_fila_detalhe" href="#"><i class="fas fa-eye"></i></a></td></tr>';
                    });
                });
                $('.list_monitor tbody').html(item);
                /*$('.tableList').DataTable({
                    "destroy"       : true,
                    "language"      : {
                        "decimal":        "",
                        "emptyTable":     "Nenhum registro para ser mostrado",
                        "info":           "Mostrando _START_ ao _END_ de _TOTAL_ registros",
                        "infoEmpty":      "Nenhum registro",
                        "infoFiltered":   "(filtered from _MAX_ total entries)",
                        "infoPostFix":    "",
                        "thousands":      ",",
                        "lengthMenu":     "Mostrar _MENU_ registros",
                        "loadingRecords": "Carregando...",
                        "processing":     "Processando...",
                        "search":         "Buscar:",
                        "zeroRecords":    "Sem correspondência",
                        "paginate": {
                            "first":      "Primeiro",
                            "last":       "Último",
                            "previous":   "Anterior",
                            "next":       "Próximo"
                        },
                        "aria": {
                            "sortAscending":  ": activate to sort column ascending",
                            "sortDescending": ": activate to sort column descending"
                        }
                    }
                });*/
            }
            

            $('.view_fila_detalhe').click(function(e){
                e.preventDefault();

                var id = $(this).data('id');

                $('.modal .modal_content').load('modal/monitor-fila.html', function(){

                    var aCategoria = data.categorias[id];

                    $('#fila_nomeCategoria').text(aCategoria.nomeCategoria);
                    $('#fila_tempoMedioEspera').text(aCategoria.tempoMedioEspera);
                    $('#fila_metaDia').text((aCategoria.metaDia/60)+' MIN.');
                    $('#fila_minAmarelo').text(aCategoria.minAmarelo);
                    $('#fila_minVermelho').text(aCategoria.minVermelho);

                    var senha_list = '';

                    for(var f = 0; f<data.categorias[id].senhaEmAberto.length; f++){
                        var oItem = data.categorias[id].senhaEmAberto[f];

                        var priorizar = oItem.priorizado == true ?
                            '<a data-set_priorizar="false" data-senha="'+oItem.senha+'" class="priorizar_senha" id="'+oItem.idAtendimento+'" href="#"><i class="fas fa-check-circle"></i></a>' :
                            '<a data-set_priorizar="true" data-senha="'+oItem.senha+'" class="priorizar_senha" id="'+oItem.idAtendimento+'" href="#"><i class="fas fa-times-circle"></i></a>';

                        var espera  = oItem.tempoEspera ? oItem.tempoEspera : 'N/A';

                        var meta    = (oItem.porcMeta/aCategoria.metaDia)*100;
                        meta = parseFloat(Math.round(meta * 100) / 100).toFixed(2);

                        var cor = '';
                        if(meta>=aCategoria.minVermelho){
                            cor = 'bg_vermelho';
                        }else if(meta>=aCategoria.minAmarelo){
                            cor = 'bg_amarelo';
                        }else{
                            cor = 'bg_verde';
                        }

                        senha_list += '<tr id="senha'+oItem.senha+'"><td><span class="bolinha '+cor+'"></span></td><td>'+oItem.senha+'</td><td>'+oItem.dtImpressao+'</td><td>'+espera+'</td><td>'+meta+'</td><td><a data-id="'+oItem.idAtendimento+'" class="cancelar_senha" href=""><i class="fas fa-times-circle"></i></a></td><td class="stt_priorizar">'+priorizar+'</td></tr>';
                    }
                    $('.list_monitor_fila tbody').html(senha_list);

                    $('.cancelar_senha').click(function(e){
                        e.preventDefault();

                        //var senha = $(this).data('senha');
                        var atend = $(this).data('id');
                        
                        print(atend);
                        var formData = {
                            'idUsuario'         : currentUser.usuarioID,
                            'token'             : currentUser.emissorToken,
                            'idAtendimento'     : atend
                        };

                        $.ajax({
                            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                            url			: ATENDIMENTO+'cancelarSenha'+suffix, // the url where we want to POST
                            contentType : 'application/json',
                            data		: JSON.stringify(formData), // our data object
                            dataType	: 'json', // what type of data do we expect back from the server
                            encode		: true
                        }).done(function(data) {

                            if(data.retorno == true){
                                print(data.idAtendimento);
                                showMessage('Senha '+data.idAtendimento+' cancelada com sucesso');
                                $('#senha'+data.idAtendimento).css({'display':'none'});

                            }

                        });
                    });


                    $('.priorizar_senha').click(function(e){
                        e.preventDefault();

                        var senha           = $(this).data('senha');
                        var atend           = $(this).attr('id')
                        var set_priorizar   = $(this).data('set_priorizar');

                        var formData = {
                            idAtendimento   : atend,
                            idUsuario       : currentUser.usuarioID,
                            token           : currentUser.emissorToken,
                            priorizar       : set_priorizar
                        };
                        $.ajax({
                            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                            url			: ATENDIMENTO+'priorizarSenha'+suffix, // the url where we want to POST
                            contentType : 'application/json',
                            data		: JSON.stringify(formData), // our data object
                            dataType	: 'json', // what type of data do we expect back from the server
                            encode		: true
                        }).done(function(data) {

                            if(data.retorno == true){
                                
                                if(data.priorizar == true){
                                    showMessage('Senha '+senha+' foi priorizada com sucesso!')
                                    $('#senha'+senha+' .stt_priorizar').html('<a data-set_priorizar="false" data-senha="'+senha+'" class="priorizar_senha" id="'+idAtendimento+'" href="#"><i class="fas fa-check-circle"></i></a>');//<i class="fas fa-check-circle"></i>
                                }else{
                                    showMessage('Senha '+senha+' foi despriorizada com sucesso!')
                                    $('#senha'+senha+' .stt_priorizar').html('<a data-set_priorizar="true" data-senha="'+senha+'" class="priorizar_senha" id="'+idAtendimento+'" href="#"><i class="fas fa-times-circle"></i></a>');//<i class="fas fa-times-circle"></i>
                                }
                            }

                        });

                    });

                }, $('.modal').fadeIn());

            });

        });
        
    });
    
}

function reloadCategoriasList(){
    
    var catAtuais;
    
    var date = new Date();
    print('monitoramento Categoria atualizado: '+date.getHours()+':'+date.getMinutes()+':'+date.getSeconds());
    
    var formData = {};

    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: UTIL+'getMonitoramentoCategoria'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {

        print(data);

        if(data){
            
            catAtuais = data;
            
            $.each(catAtuais, function() {
                $.each(this, function(k, v) {
                    
                    var cor_item = '';
                    
                    var bg_verde    = false;
                    var bg_amarelo  = false;
                    var bg_vermelho = false;
                    
                    $.each(v.senhaEmAberto, function(k, v2) {
                        
                        var meta    = (v2.porcMeta/v.metaDia)*100;
                        meta = parseFloat(Math.round(meta * 100) / 100).toFixed(2);
                        
                        if(meta >= v.minVermelho){
                            bg_vermelho = true;
                        }else if(meta >= v.minAmarelo){
                            bg_amarelo = true;
                        }else{
                            bg_verde = true;
                        }
                        
                    });
                    
                    if(bg_verde == true){
                        print('bg_verde');
                        cor_item = 'bg_verde';
                    }
                    if(bg_amarelo == true){
                        print('bg_amarelo');
                        cor_item = 'bg_amarelo';
                    }
                    if(bg_vermelho == true){
                        print('bg_vermelho');
                        cor_item = 'bg_vermelho';
                    }
                    
                    $('#categoria'+v.idCategoria+' .totalSenhaEmAberto').text(v.totalSenhaEmAberto);
                    $('#categoria'+v.idCategoria+' .status').html('<span class="bolinha '+cor_item+'"></span>');

                });
            });
        }

        $('.view_fila_detalhe').click(function(e){
            e.preventDefault();

            var id = $(this).data('id');

            $('.modal .modal_content').load('modal/monitor-fila.html', function(){

                var aCategoria = catAtuais.categorias[id];

                $('#fila_nomeCategoria').text(aCategoria.nomeCategoria);
                $('#fila_tempoMedioEspera').text(aCategoria.tempoMedioEspera);
                $('#fila_metaDia').text((aCategoria.metaDia/60)+' MIN.');
                $('#fila_minAmarelo').text(aCategoria.minAmarelo);
                $('#fila_minVermelho').text(aCategoria.minVermelho);

                var senha_list = '<tr><th>SENHA</th><th>DT IMPRESSÃO</th><th>ESPERA</th><th>META %</th><th>CANCELAR</th><th>PRIORIZADO</th></tr>';

                for(var f = 0; f<catAtuais.categorias[id].senhaEmAberto.length; f++){
                    var oItem = catAtuais.categorias[id].senhaEmAberto[f];

                    var priorizar = oItem.priorizado == true ?
                        '<a data-priorizado="false" data-id_atendimento="'+oItem.idAtendimento+'" class="priorizar_senha" id="'+oItem.idAtendimento+'" href="#"><i class="fas fa-check-circle"></i></a>' :
                        '<a data-priorizado="true" data-id_atendimento="'+oItem.idAtendimento+'" class="priorizar_senha" id="'+oItem.idAtendimento+'" href="#"><i class="fas fa-times-circle"></i></a>';

                    var espera  = oItem.tempoEspera ? oItem.tempoEspera : 'N/A';

                    var meta    = (oItem.porcMeta/aCategoria.metaDia)*100;
                    meta = parseFloat(Math.round(meta * 100) / 100).toFixed(2);

                    var cor = '';
                    if(meta>=aCategoria.minVermelho){
                        cor = 'bg_vermelho';
                    }else if(meta>=aCategoria.minAmarelo){
                        cor = 'bg_amarelo';
                    }else{
                        cor = 'bg_verde';
                    }

                    senha_list += '<tr id="senha'+oItem.idAtendimento+'"><td><span class="bolinha '+cor+'"></span>'+oItem.senha+'</td><td>'+oItem.dtImpressao+'</td><td>'+espera+'</td><td>'+meta+'</td><td><a data-id="'+oItem.idAtendimento+'" class="cancelar_senha" href=""><i class="fas fa-times-circle"></i></a></td><td>'+priorizar+'</td></tr>';
                }
                $('.list_monitor_fila').html(senha_list);

                $('.cancelar_senha').click(function(e){
                    e.preventDefault();

                    var senha = $(this).data('id');
                    var formData = {
                        'idUsuario'         : currentUser.usuarioID,
                        'token'             : currentUser.emissorToken,
                        'idAtendimento'     : senha
                    };

                    $.ajax({
                        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url			: ATENDIMENTO+'cancelarSenha'+suffix, // the url where we want to POST
                        contentType : 'application/json',
                        data		: JSON.stringify(formData), // our data object
                        dataType	: 'json', // what type of data do we expect back from the server
                        encode		: true
                    }).done(function(data) {

                        if(data.retorno == true){
                            print(data.idAtendimento);
                            showMessage('Senha '+data.idAtendimento+' cancelada com sucesso');
                            $('#senha'+data.idAtendimento).css({'display':'none'});

                        }

                    });
                });


                $('.priorizar_senha').click(function(e){
                    e.preventDefault();

                    var id_atendimento  = $(this).data('id_atendimento');
                    var priorizado      = $(this).data('priorizado');

                    var formData = {
                        idAtendimento   : id_atendimento,
                        idUsuario       : currentUser.usuarioID,
                        token           : currentUser.emissorToken,
                        priorizar       : priorizado
                    };
                    $.ajax({
                        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url			: ATENDIMENTO+'priorizarSenha'+suffix, // the url where we want to POST
                        contentType : 'application/json',
                        data		: JSON.stringify(formData), // our data object
                        dataType	: 'json', // what type of data do we expect back from the server
                        encode		: true
                    }).done(function(data) {

                        if(data.retorno == true){
                            if(data.priorizar == true){
                                showMessage('Senha '+id_atendimento+' foi priorizada com sucesso!')
                                $('#'+id_atendimento).html('<i class="fas fa-check-circle"></i>');
                            }else{
                                showMessage('Senha '+id_atendimento+' foi despriorizada com sucesso!')
                                $('#'+id_atendimento).html('<i class="fas fa-times-circle"></i>');
                            }
                        }

                    });

                });

            }, $('.modal').fadeIn());

        });

    });
    
}

function getMonitoramentoSenhas(){
    
    contagemCaixasStop();
    contagemCategoriasStop();
    
    $('#main .main_content').load('content/monitor-senhas.html', function(){
        
        $('.view_categorias_filas').click(function(e){
            e.preventDefault();

            getMonitoramentoCategoria();
            contagemCategoriasStart();
        });

        $('.view_historico_senhas').click(function(e){
            e.preventDefault();

            //getMonitoramentoSenhas();
        });

        $('.view_historico_caixas').click(function(e){
            e.preventDefault();

            getMonitoramentoCaixas();
            contagemCaixasStart();
        });
        
        $('.bt_Export').click(function(e){
            e.preventDefault();
            
        });
        
        reloadSenhasList();
        
    });
}

function reloadSenhasList(){
    
    var date = new Date();
    print('monitoramento Senhas atualizado: '+date.getHours()+':'+date.getMinutes()+':'+date.getSeconds());
    
    var formData = {};

    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: UTIL+'buscaMonitoramentoSenhas'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {

        print(data);
        $('#monitor_senhas_data').text(hoje);

        var item = '';

        if(data){
            $.each(data, function() {
                $.each(this, function(k, v) {

                    print(v);
                    var meta = (v.porcentagemMeta/v.categoria.metaDia)*100;
                    meta     = parseFloat(Math.round(meta * 100) / 100).toFixed(2);

                    var priorizada = v.flgPriorizada == true ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-times-circle"></i>';

                    item += '<tr><td>'+v.senha+'</td><td>'+v.dtImpressao+'</td><td>'+v.dtInicioAtendimento+'</td><td>'+v.dtFim+'</td><td>'+v.tme+'</td><td>'+v.tma+'</td><td>'+v.terminalPosicao+'</td><td>'+v.nomeUsuario+'</td><td>'+meta+'</td><td>'+v.status+'</td><td>'+priorizada+'</td></tr>';
                });
            });
        }
        $('.list_monitor_senhas tbody').html(item);
        /*$('.tableList').DataTable({
            "destroy"       : true,
            "language"      : {
                "decimal":        "",
                "emptyTable":     "Nenhum registro para ser mostrado",
                "info":           "Mostrando _START_ ao _END_ de _TOTAL_ registros",
                "infoEmpty":      "Nenhum registro",
                "infoFiltered":   "(filtered from _MAX_ total entries)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     "Mostrar _MENU_ registros",
                "loadingRecords": "Carregando...",
                "processing":     "Processando...",
                "search":         "Buscar:",
                "zeroRecords":    "Sem correspondência",
                "paginate": {
                    "first":      "Primeiro",
                    "last":       "Último",
                    "previous":   "Anterior",
                    "next":       "Próximo"
                },
                "aria": {
                    "sortAscending":  ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                }
            }
        });*/

    });
    
}

function getMonitoramentoCaixas(){
    
    contagemSenhasStop();
    contagemCategoriasStop();
    
    $('#main .main_content').load('content/monitor-caixas.html', function(){
        
        $('.view_categorias_filas').click(function(e){
            e.preventDefault();

            getMonitoramentoCategoria();
            contagemCategoriasStart();
        });

        $('.view_historico_senhas').click(function(e){
            e.preventDefault();

            getMonitoramentoSenhas();
            contagemSenhasStart();
        });

        $('.view_historico_caixas').click(function(e){
            e.preventDefault();

            //getMonitoramentoCaixas();
        });
        
        $('.bt_Export').click(function(e){
            e.preventDefault();
            
        });
        
        reloadCaixasList();

    });
}

function reloadCaixasList(){
    
    var date = new Date();
    print('monitoramento Caixas atualizado: '+date.getHours()+':'+date.getMinutes()+':'+date.getSeconds());
    
    var formData = {};

    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: UTIL+'buscaMonitoramentoCaixa'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {

        print(data);
        $('#monitor_caixas_data').text(hoje);

        var item = '';

        if(data){
            $.each(data, function() {
                $.each(this, function(k, v) {

                    print(v);

                    var usuario = v.usuario ? v.usuario : 'N/A';
                    var dtLogin = v.dtLogin ? v.dtLogin : 'N/A';
                    var senhaAtual = v.senhaAtual ? v.senhaAtual : 'N/A';
                    var nomeCategoria = v.nomeCategoria ? v.nomeCategoria : 'N/A';

                    item += '<tr><td>'+usuario+'</td><td>'+dtLogin+'</td><td>'+senhaAtual+'</td><td>'+nomeCategoria+'</td><td>'+v.tmpAtdtAtual+'</td><td>'+v.tma+'</td><td>'+v.qtdeAtdt+'</td><td>'+v.politicaFormatada+'</td><td>'+v.tmpOcioso+'</td></tr>';
                });
            });
        }
        $('.list_monitor_caixas tbody').html(item);
        /*$('.tableList').DataTable({
            //"destroy"       : true,
            "language"      : {
                "decimal":        "",
                "emptyTable":     "Nenhum registro para ser mostrado",
                "info":           "Mostrando _START_ ao _END_ de _TOTAL_ registros",
                "infoEmpty":      "Nenhum registro",
                "infoFiltered":   "(filtered from _MAX_ total entries)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     "Mostrar _MENU_ registros",
                "loadingRecords": "Carregando...",
                "processing":     "Processando...",
                "search":         "Buscar:",
                "zeroRecords":    "Sem correspondência",
                "paginate": {
                    "first":      "Primeiro",
                    "last":       "Último",
                    "previous":   "Anterior",
                    "next":       "Próximo"
                },
                "aria": {
                    "sortAscending":  ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                }
            }
        });*/
    });
    
}


function loadConfiguracoes(){
    
    showBarsMenu();
    $('#footer').css({'display':'none'});
    //$('#nome_atendente').text(currentUser.usuarioNome);
    
    contagemBuscaStop();
    contagemCategoriasStop();
    contagemSenhasStop();
    contagemCaixasStop();
    getAgencia();
                                  
}

function getAgencia(){
    
    $('#main .main_content').load('content/configuracoes-agencia.html', function(){
        
        $('#bt_cnf_agencia').click(function(e){
            e.preventDefault();

            getAgencia();
        });
        
        $('#bt_cnf_usuarios').click(function(e){
            e.preventDefault();

            getUsuarios();
        });

        $('#bt_cnf_categorias').click(function(e){
            e.preventDefault();

            getCategorias();
        });
        
        $('#bt_cnf_terminais').click(function(e){
            e.preventDefault();

            getTerminais();
        });
        
        $('#bt_cnf_paineis').click(function(e){
            e.preventDefault();

            getPaineis();
        });
        
        var formData = {};

        $.ajax({
            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url			: AGENCIA+'getAgencia'+suffix, // the url where we want to POST
            contentType : 'application/json',
            data		: JSON.stringify(formData), // our data object
            dataType	: 'json', // what type of data do we expect back from the server
            encode		: true
        }).done(function(data) {
            
            //print(data);
            
            $('#ag_codigo').text(data.idAgencia);
            $('#ag_nome').text(data.nomeAgencia);
            $('#ag_responsavel').text(data.nomeResponsavel);
            $('#ag_email').text(data.emailResponsavel);
            $('#ag_telefone').text(data.foneResponsavel);
            
            $('#user_codigo').text(currentUser.usuarioID);
            $('#user_nome').text(currentUser.usuarioNome);
            $('#user_matricula').text(currentUser.usuarioID);
            $('#user_ip').text('N/A');
            $('#user_rede').text('N/A');
        });
        
    });
    
}

function addPainel(painel){
    
    $(painel).appendTo("#showPaineis");
    var id = $(painel).data('id');
    
    var n = 0;
    for(var i=0; i<4; i++){
        n = i+1;
        if($('#idPainel'+n).val() == 0){
            $('#idPainel'+n).val(id);
            return;
        }
    }
    
}

function removePainel(painel){
    
    $(painel).appendTo(".paineis_disponiveis");
    var id = $(painel).data('id');
    
    var n = 0;
    var ativos = [];
    for(var r=0; r<4; r++){
        n = r+1;
        if(($('#idPainel'+n).val() != 0) && ($('#idPainel'+n).val() != id)){
            ativos.push($('#idPainel'+n).val());
        }
    }
    
    // Adiciono reordenado
    n = 0;
    for(var d=0; d<4; d++){
        n = d+1;
        $('#idPainel'+n).val('0');
        print('#idPainel'+n+' = '+$('#idPainel'+n).val());
    }
    
    n = 0;
    for(var a=0; a<ativos.length; a++){
        n = a+1;
        print('valor: '+ativos[a]);
        $('#idPainel'+n).val(ativos[a]);
    }
    
}

function getUsuarios(){
    
    $('#main .main_content').load('content/configuracoes-usuarios.html', function(){
        
        $('#bt_cnf_agencia').click(function(e){
            e.preventDefault();

            getAgencia();
        });
        
        $('#bt_cnf_usuarios').click(function(e){
            e.preventDefault();

            getUsuarios();
        });

        $('#bt_cnf_categorias').click(function(e){
            e.preventDefault();

            getCategorias();
        });
        
        $('#bt_cnf_terminais').click(function(e){
            e.preventDefault();

            getTerminais();
        });
        
        $('#bt_cnf_paineis').click(function(e){
            e.preventDefault();

            getPaineis();
        });
        
        var formData = {};

        $.ajax({
            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url			: UTIL+'buscaUsuarios'+suffix, // the url where we want to POST
            contentType : 'application/json',
            data		: JSON.stringify(formData), // our data object
            dataType	: 'json', // what type of data do we expect back from the server
            encode		: true
        }).done(function(data) {
            
            //print(data);
            
            var linhas = "";
            for(var i=0; i<data.usuarios.length; i++){
                
                var usuario = data.usuarios[i];
                var status  = usuario.habilitado?'Ativo':'Inativo';
                linhas += "<tr><td class='align_left'>"+usuario.nome+"</td><td>"+usuario.idUsuario+"</td><td>"+usuario.tipoUsuario+"</td><td>"+status+"</td><td><a class='edit' data-data='"+JSON.stringify(usuario)+"' href=''><i class='fas fa-edit'></i></a></td></tr>";
                
            }
            $('#cnf_lista_usuarios tbody').html(linhas);
            
            
            $('.edit').click(function(e){
                e.preventDefault();
                
                var data    = $(this).data('data');
                
                $('.modal .modal_content').load('modal/crud-usuarios.html', function(){
        
                    // Varre data para popular campos para edição
                    if (typeof data != undefined) {
                        $.each(data, function(k, v) {
                            
                            $('#'+k).val(v.toString());
                            
                        });
                    }

                    $('#cancelar').click(function(e){
                        e.preventDefault();

                        closeModal();
                    });

                    $('form').submit(function(e){
                        e.preventDefault();
                        
                        var formData = {
                            "usuarioResponsavelId" : currentUser.usuarioID,
                            "flgHabilitado"     : $('#habilitado option:selected').val(),
                            "fone"              : $('#telefone').val(),
                            "emailUsuario"      : $('#email').val(),
                            "nomeUsuario"       : $('#nome').val(),
                            "idUsuario"         : $('#idUsuario').val(),
                            "matricula"         : $('#matricula').val(),
                            "perfil":{
                                "codPerfilUnidade"  : $('#idTipoUsuario').val(),
                                "descr"             : $('#idTipoUsuario option:selected').text()
                            }
                        };

                        //print(formData);
                        $.ajax({
                            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                            url			: UTIL+'crudUsuario'+suffix, // the url where we want to POST
                            contentType : 'application/json',
                            data		: JSON.stringify(formData), // our data object
                            dataType	: 'json', // what type of data do we expect back from the server
                            encode		: true
                        }).done(function(data) {

                            if(data.status == true){

                                closeModal();
                                getUsuarios();

                            }else{
                                showMessage(data.msg);
                            }

                        }); 
                    });

                }, $('.modal').fadeIn());
                
            });
            
            $('.add_btn a').click(function(e){
                e.preventDefault();
                
                $('.modal .modal_content').load('modal/crud-usuarios.html', function(){

                    $('#cancelar').click(function(e){
                        e.preventDefault();

                        closeModal();
                    });

                    $('form').submit(function(e){
                        e.preventDefault();

                        var formData = {
                            "usuarioResponsavelId" : currentUser.usuarioID,
                            "flgHabilitado"     : $('#habilitado option:selected').val(),
                            "fone"              : $('#telefone').val(),
                            "emailUsuario"      : $('#email').val(),
                            "nomeUsuario"       : $('#nome').val(),
                            "idUsuario"         : 0,
                            "matricula"         : $('#matricula').val(),
                            "perfil":{
                                "codPerfilUnidade":$('#idTipoUsuario').val(),
                                "descr":$('#idTipoUsuario option:selected').text()
                            }
                        };

                        print(formData);
                        $.ajax({
                            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                            url			: UTIL+'crudUsuario'+suffix, // the url where we want to POST
                            contentType : 'application/json',
                            data		: JSON.stringify(formData), // our data object
                            dataType	: 'json', // what type of data do we expect back from the server
                            encode		: true
                        }).done(function(data) {

                            if(data.status == true){

                                closeModal();
                                getUsuarios();

                            }else{
                                showMessage(data.msg);
                            }

                        }); 
                    });

                }, $('.modal').fadeIn());
                
            });
            
            
        });
        
    });
    
}

function getCategorias(){
    
    $('#main .main_content').load('content/configuracoes-categorias.html', function(){
        
        $('#bt_cnf_agencia').click(function(e){
            e.preventDefault();

            getAgencia();
        });
        
        $('#bt_cnf_usuarios').click(function(e){
            e.preventDefault();

            getUsuarios();
        });

        $('#bt_cnf_categorias').click(function(e){
            e.preventDefault();

            getCategorias();
        });
        
        $('#bt_cnf_terminais').click(function(e){
            e.preventDefault();

            getTerminais();
        });
        
        $('#bt_cnf_paineis').click(function(e){
            e.preventDefault();

            getPaineis();
        });
        
        var formData = {};

        $.ajax({
            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url			: UTIL+'buscaCategorias'+suffix, // the url where we want to POST
            contentType : 'application/json',
            data		: JSON.stringify(formData), // our data object
            dataType	: 'json', // what type of data do we expect back from the server
            encode		: true
        }).done(function(data) {
            
            //print(data);
            
            var linhas = "";
            for(var i=0; i<data.categoria.length; i++){
                
                var cat = data.categoria[i];
                //print(usuario);
                linhas += "<tr><td class='align_left'>"+cat.nomeCategoria+"</td><td>"+cat.tipoCategoria+"</td><td>"+cat.minAmarelo+"</td><td>"+cat.minVermelho+"</td><td><a class='edit' data-data='"+JSON.stringify(cat)+"' href=''><i class='fas fa-edit'></i></a></td></tr>";
                
            }
            $('#cnf_lista_categorias tbody').html(linhas);
            
            $('.edit').click(function(e){
                e.preventDefault();
                
                var data    = $(this).data('data');
                //var getCrud = 'updateCategoria';
                
                //crud('categorias', data, getCrud);
                
                
                $('.modal .modal_content').load('modal/crud-categorias.html', function(){
        
                    var paineisAtivos = [];
                    
                    // Varre data para popular campos para edição
                    if (typeof data != undefined) {
                        $.each(data, function(k, v) {
                            $('#'+k).val(v);
                            
                            if(v === true){
                                $("#"+k).prop( "checked", true );
                            }else if(v === false){
                                $("#"+k).prop( "checked", false );
                            }
                            
                            if(k=='metaDia'){
                                $('#'+k).val(v/60);
                            }
                            
                            if(k=='paineis'){
                                $.each(v, function(k, v) {
                                    paineisAtivos.push(v.id);
                                });
                            }
                            
                        });
                    }

                    // Lista Painéis disponíveis quando crud = categoria
                    $.ajax({
                        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url			: UTIL+'buscaPaineis'+suffix, // the url where we want to POST
                        contentType : 'application/json',
                        data		: '', // our data object
                        dataType	: 'json', // what type of data do we expect back from the server
                        encode		: true
                    }).done(function(data) {

                        //print(data);
                        var paineis_disponiveis = '';
                        if (typeof data != undefined && data.display.length > 0) {
                            for(var i=0; i<data.display.length; i++){

                                var painel  = data.display[i];
                                //print(painel);
                                paineis_disponiveis += '<div id="painel'+painel.id+'" class="bt_painel" data-id="'+painel.id+'"><a title="'+painel.id+'" href="#">'+painel.hostname+'</a></div>';

                            }
                        }
                        //print(paineis_disponiveis);
                        $('.paineis_disponiveis').html(paineis_disponiveis);

                        // Adicionar função pra jogar painéis já existentes no
                        for(var pa = 0; pa<paineisAtivos.length; pa++){
                            addPainel($('#painel'+paineisAtivos[pa]));
                        }
                        

                        $('.paineis_disponiveis').click('.bt_painel', function(e){
                            e.preventDefault();

                            addPainel(this);
                        });
                        $('#showPaineis').click('.bt_painel', function(e){
                            e.preventDefault();

                            removePainel(this);
                        });

                    });

                    $('#cancelar').click(function(e){
                        e.preventDefault();

                        closeModal();
                    });

                    $('form').submit(function(e){
                        e.preventDefault();

                        
                        var formData = {
                            "nomeFila"          : $('#nomeCategoria').val(),
                            "senhaIni"          : $('#rangeInicial').val(),
                            "senhaFim"          : $('#rangeFinal').val(),
                            "tminAmarelo"       : $('#minAmarelo').val(),
                            "tminVermelho"      : $('#minVermelho').val(),
                            "tmeMetaDia"        : $('#metaDia').val()*60,
                            "idPainel1"         : $('#idPainel1').val(),
                            "idPainel2"         : $('#idPainel2').val(),
                            "idPainel3"         : $('#idPainel3').val(),
                            "idPainel4"         : $('#idPainel4').val(),
                            "identificacao"     : $('#tipoCategoria').val(),
                            "tipoFila"          : $('#tipoCategoria').val(),
                            "idCategoria"       : $('#idCategoria').val(),
                            "idLocalAtendimento": $('#idLocalAtendimento').val(),
                            "flgIsCliente"      : true,
                            "flgIdentificacao"  : true,
                            "idNivelSegmento"   : 1,
                            "incrementalSenha"  : 1,
                            "porcentagemExclusaoAtendimento"    : 0,
                            "idUsuarioResponsavel"              : currentUser.usuarioID
                        };
                        
                        //print(formData);
                        $.ajax({
                            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                            url			: UTIL+'updateCategoria'+suffix, // the url where we want to POST
                            contentType : 'application/json',
                            data		: JSON.stringify(formData), // our data object
                            dataType	: 'json', // what type of data do we expect back from the server
                            encode		: true
                        }).done(function(data) {

                            if(data.status == true){

                                closeModal();
                                getCategorias();

                            }

                        }); 
                    });

                }, $('.modal').fadeIn());
                
            });
            
        });
        
    });
    
}

function getTerminais(){
    
    $('#main .main_content').load('content/configuracoes-terminais.html', function(){
        
        $('#bt_cnf_agencia').click(function(e){
            e.preventDefault();

            getAgencia();
        });
        
        $('#bt_cnf_usuarios').click(function(e){
            e.preventDefault();

            getUsuarios();
        });

        $('#bt_cnf_categorias').click(function(e){
            e.preventDefault();

            getCategorias();
        });
        
        $('#bt_cnf_terminais').click(function(e){
            e.preventDefault();

            getTerminais();
        });
        
        $('#bt_cnf_paineis').click(function(e){
            e.preventDefault();

            getPaineis();
        });
        
        var formData = {};

        $.ajax({
            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url			: UTIL+'buscaCaixas'+suffix, // the url where we want to POST
            contentType : 'application/json',
            data		: JSON.stringify(formData), // our data object
            dataType	: 'json', // what type of data do we expect back from the server
            encode		: true
        }).done(function(data) {
            
            print(data);
            
            var linhas = "";
            for(var i=0; i<data.caixa.length; i++){
                
                var terminal = data.caixa[i];
                
                var status = terminal.isLogado ? 'Sim' : 'Não';
                linhas += "<tr><td class='align_left'>"+terminal.aliasCaixa+"</td><td>"+terminal.hostname+"</td><td>"+terminal.tipoCaixa+"</td><td>"+status+"</td><td><a class='edit' data-data='"+JSON.stringify(terminal)+"' href='#'><i class='fas fa-edit'></i></a></td></tr>";
                
            }
            $('#cnf_lista_terminais tbody').html(linhas);
            
            $('.edit').click(function(e){
                e.preventDefault();
                
                var data    = $(this).data('data');
                
                print(data);
                
                $('.modal .modal_content').load('modal/crud-terminais.html', function(){
                    
        
                    var tipoCx = '';
                    // Varre data para popular campos para edição
                    if (typeof data != undefined) {
                        $.each(data, function(k, v) {
                            $('#'+k).val(v);
                            
                            if(v === true){
                                $("#"+k).val("Sim");
                            }else if(v === false){
                                $("#"+k).val("Não");
                            }
                            
                            if(k === 'tipoCaixa'){
                                tipoCx = data.tipoCaixa
                            }
                            
                            if(k === 'politicaFormatada'){
                                
                                var quebraPolitica = v.split('');
                                
                                var colcA = '<button class="tool_item bt_colcheteAbre abreColchete" disabled>[</button>';
                                var colcF = '<button class="tool_item bt_colcheteFecha fechaColchete" disabled>]</button>';
                                var chavA = '<button class="tool_item bt_chaveAbre abreChave" disabled>{</button>';
                                var chavF = '<button class="tool_item bt_chaveFecha fechaChave" disabled>}</button>';
                                var barra = '<button class="tool_item bt_barra barra" disabled>/</button>';
                                var excla = '<button class="tool_item bt_exclamacao exclamacao" disabled>!</button>';
                                
                                for(var p = 0; p<quebraPolitica.length; p++){
                                    
                                    var carac = quebraPolitica[p];
                                    
                                    var letra = '<button disabled>'+carac+'</button>';
                                        
                                    if(carac == '/'){
                                        addElement(barra);
                                        
                                    }else if(carac == '!'){
                                        addElement(excla);
                                    
                                    }else if(carac == '['){
                                        addElement(colcA);
                                        
                                    }else if(carac == ']'){
                                        addElement(colcF);
                                        
                                    }else if(carac == '{'){
                                        addElement(chavA);
                                        
                                    }else if(carac == '}'){
                                        addElement(chavF);
                                        
                                    }else{
                                        addElement(letra);
                                        
                                    }
                                    
                                }
                                
                                //print(montaPolitica);
                                
                            }
                            
                        });
                    }

                    $('#cancelar').click(function(e){
                        e.preventDefault();

                        closeModal();
                    });
                    
                    var listaCxPosicao = '';
                    $.ajax({
                        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url			: UTIL+'buscaTipoCaixaPosicao'+suffix, // the url where we want to POST
                        contentType : 'application/json',
                        data		: JSON.stringify(formData), // our data object
                        dataType	: 'json', // what type of data do we expect back from the server
                        encode		: true
                    }).done(function(data) {

                        print(data);
                        
                        for(var p = 0; p<data.tipoCaixaPosicao.length; p++){

                            var posicao = data.tipoCaixaPosicao[p];
                            listaCxPosicao += '<option value="'+posicao.descricaotipoPosicao+'">'+posicao.descricaotipoPosicao+'</option>';

                        }
                        $('#tipoCaixa').html(listaCxPosicao);
                        
                        $('#tipoCaixa').val(tipoCx);
                        
                    });
                    
                    
                    $.ajax({
                        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url			: UTIL+'buscaCategorias'+suffix, // the url where we want to POST
                        contentType : 'application/json',
                        data		: JSON.stringify(formData), // our data object
                        dataType	: 'json', // what type of data do we expect back from the server
                        encode		: true
                    }).done(function(data) {

                        if(data){
                        
                            var LETRAS = '';
                            var listaLetras = '';
                            for(var l = 0; l<data.categoria.length; l++){

                                LETRAS = data.categoria[l];
                                listaLetras += '<button>'+$.trim(LETRAS.tipoCategoria)+'</button>';// data-id="'+LETRAS.idCategoria+'"

                            }
                            $('#teclado_letras').html(listaLetras);


                            var TOOLS = '<button class="tool_item bt_colcheteAbre abreColchete">[</button><button class="tool_item bt_colcheteFecha fechaColchete" disabled>]</button><button class="tool_item bt_chaveAbre abreChave">{</button><button class="tool_item bt_chaveFecha fechaChave" disabled>}</button><button class="tool_item bt_barra barra">/</button><button class="tool_item bt_exclamacao exclamacao">!</button><button class="tool_item bt_asterisco asterisco">*</button>';

                            $('#teclado_tools').html(TOOLS);


                            $('.barra').click(function(e){
                                e.preventDefault();

                                addElement(this);
                            });

                            $('.exclamacao').click(function(e){
                                e.preventDefault();

                                addElement(this);
                            });

                            $('.abreColchete').click(function(e){
                                e.preventDefault();

                                addElement(this);
                            });

                            $('.fechaColchete').click(function(e){
                                e.preventDefault();

                                addElement(this);
                            });

                            $('.abreChave').click(function(e){
                                e.preventDefault();

                                addElement(this);
                            });

                            $('.fechaChave').click(function(e){
                                e.preventDefault();

                                addElement(this);
                            });

                            $('#teclado_letras button').click(function(e){
                                e.preventDefault();

                                addElement(this);
                            });

                            $('.limparUltimo').click(function(e){
                                e.preventDefault();

                                removeElement();
                            });
                        }

                    });
                    $('#showPolitica button').click(function(e){
                        e.preventDefault();
                        
                    });
                    
                    
                    $('form').submit(function(e){
                        e.preventDefault();
                        
                        if($('#tipoCaixa option:selected').val() === 'NA'){
                            
                            showMessage('Tipo da Posição não pode ser NA');
                            
                        }else{
                            
                            if(verificaPolitica()){

                                var formData = {
                                    "hostname"              : $('#hostname').val(),
                                    "politicaAtend"         : $('#showPolitica button').text(),
                                    "tipoCaixa"             : $('#tipoCaixa option:selected').val(),
                                    "aliasCaixa"            : $('#aliasCaixa').val(),
                                    "flgHabilitado"         : true,
                                    "usuarioResponsavelId"  : currentUser.usuarioID
                                };

                                //print(formData);
                                $.ajax({
                                    type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                                    url			: UTIL+'crudCaixa'+suffix, // the url where we want to POST
                                    contentType : 'application/json',
                                    data		: JSON.stringify(formData), // our data object
                                    dataType	: 'json', // what type of data do we expect back from the server
                                    encode		: true
                                }).done(function(data) {

                                    if(data.status == true){

                                        closeModal();
                                        showMessage(data.msg);
                                        getTerminais();

                                    }else{
                                        showMessage(data.msg);
                                    }

                                });

                            }else{
                                showMessage('Política mal formatada. Verifique e tente novamente.');
                            }
                            
                        }
                        
                        
                        
                    });

                }, $('.modal').fadeIn());
                
            });
            
            $('.add_btn a').click(function(e){
                e.preventDefault();
                
                $('.modal .modal_content').load('modal/crud-terminais.html', function(){

                    $('#cancelar').click(function(e){
                        e.preventDefault();

                        closeModal();
                    });
                    
                    var listaCxPosicao = '';
                    $.ajax({
                        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url			: UTIL+'buscaTipoCaixaPosicao'+suffix, // the url where we want to POST
                        contentType : 'application/json',
                        data		: JSON.stringify(formData), // our data object
                        dataType	: 'json', // what type of data do we expect back from the server
                        encode		: true
                    }).done(function(data) {

                        print(data);
                        
                        for(var p = 0; p<data.tipoCaixaPosicao.length; p++){

                            var posicao = data.tipoCaixaPosicao[p];
                            listaCxPosicao += '<option value="'+posicao.descricaotipoPosicao+'">'+posicao.descricaotipoPosicao+'</button>';

                        }
                        $('#tipoCaixa').html(listaCxPosicao);
                        
                    });
                    
                    $.ajax({
                        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url			: UTIL+'buscaCategorias'+suffix, // the url where we want to POST
                        contentType : 'application/json',
                        data		: JSON.stringify(formData), // our data object
                        dataType	: 'json', // what type of data do we expect back from the server
                        encode		: true
                    }).done(function(data) {

                        var LETRAS = '';
                        var listaLetras = '';
                        for(var l = 0; l<data.categoria.length; l++){

                            LETRAS = data.categoria[l];
                            listaLetras += '<button>'+$.trim(LETRAS.tipoCategoria)+'</button>';//data-id="'+LETRAS.idCategoria+'"

                        }
                        $('#teclado_letras').html(listaLetras);
                        
                        
                        var TOOLS = '<button class="tool_item bt_colcheteAbre abreColchete">[</button><button class="tool_item bt_colcheteFecha fechaColchete" disabled>]</button><button class="tool_item bt_chaveAbre abreChave">{</button><button class="tool_item bt_chaveFecha fechaChave" disabled>}</button><button class="tool_item bt_barra barra">/</button><button class="tool_item bt_exclamacao exclamacao">!</button><button class="tool_item bt_asterisco asterisco">*</button>';
                        
                        $('#teclado_tools').html(TOOLS);
                        
                        
                        $('.barra').click(function(e){
                            e.preventDefault();
                            
                            addElement(this);
                        });
                        
                        $('.exclamacao').click(function(e){
                            e.preventDefault();
                            
                            addElement(this);
                        });
                        
                        $('.abreColchete').click(function(e){
                            e.preventDefault();
                            
                            addElement(this);
                        });
                        
                        $('.fechaColchete').click(function(e){
                            e.preventDefault();
                            
                            addElement(this);
                        });
                        
                        $('.abreChave').click(function(e){
                            e.preventDefault();
                            
                            addElement(this);
                        });
                        
                        $('.fechaChave').click(function(e){
                            e.preventDefault();
                            
                            addElement(this);
                        });
                        
                        $('#teclado_letras button').click(function(e){
                            e.preventDefault();
                            
                            addElement(this);
                        });
                        
                        $('.limparUltimo').click(function(e){
                            e.preventDefault();
                            
                            removeElement();
                        });

                    });

                    $('form').submit(function(e){
                        e.preventDefault();
                        
                        
                        if($('#tipoCaixa option:selected').val() === 'NA'){
                            
                            showMessage('Tipo da Posição não pode ser NA');
                            
                        }else{
                            
                            if(verificaPolitica()){
                            
                                var formData = {
                                    "hostname"              : $('#hostname').val(),
                                    "politicaAtend"         : $('#showPolitica button').text(),
                                    "tipoCaixa"             : $('#tipoCaixa option:selected').val(),
                                    "aliasCaixa"            : $('#aliasCaixa').val(),
                                    "flgHabilitado"         : true,
                                    "usuarioResponsavelId"  : currentUser.usuarioID
                                };

                                print(formData);

                                $.ajax({
                                    type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                                    url			: UTIL+'crudCaixa'+suffix, // the url where we want to POST
                                    contentType : 'application/json',
                                    data		: JSON.stringify(formData), // our data object
                                    dataType	: 'json', // what type of data do we expect back from the server
                                    encode		: true
                                }).done(function(data) {

                                    if(data.status == true){

                                        closeModal();
                                        showMessage(data.msg);
                                        getTerminais();

                                    }else{
                                        showMessage(data.msg);
                                    }

                                });

                            }else{

                                showMessage('Política mal formatada. Verifique e tente novamente.');

                            }
                        }
                        
                    });

                }, $('.modal').fadeIn());
                
            });

        });
        
    });
    
}



function addElement(elem){
    $(elem).clone().appendTo("#showPolitica");
    $("#showPolitica button").attr("disabled", true);
    
    if(!verificaPolitica()){
        $('#statusPolitica').html('<i class="fas fa-times-circle"></i>');
    }else{
        $('#statusPolitica').html('<i class="fas fa-check-circle"></i>');
    }
}
function removeElement(){
    $("#showPolitica button").last().remove();
    
    if(!verificaPolitica()){
        $('#statusPolitica').html('<i class="fas fa-times-circle"></i>');
    }else{
        $('#statusPolitica').html('<i class="fas fa-check-circle"></i>');
    }
}

function verificaPolitica(){
    
    var strAtual = $("#showPolitica button").text();
    
    if(strAtual.indexOf('/') != -1 || strAtual.indexOf('!') != -1){
        ativarTeclado('bt_barra, bt_exclamacao');
        return true;
    }
        
    if(strAtual==''){
        ativarTeclado('bt_chaveAbre, bt_colcheteAbre, bt_barra, bt_exclamacao');
        return false;
    }
    var spl      = strAtual.split('');
    
    print(spl);
    //return;
    
    var colc    = false;
    var chav    = false;
    for(var c=0; c<spl.length; c++){
        
        var car = spl[c];
        
        if(car === '['){
            //print('[: '+car);
            colc = true;
        }else if(car === ']'){
            //print(']: '+car);
            colc = false;
        }
        
        if(car === '{'){
            //print('{: '+car);
            chav = true;
        }else if(car === '}'){
            //print('}: '+car);
            chav = false;
        }
        //print(strAtual);
        //print('////////////');
        
    }
    
    print('colc: '+ colc);
    print('chav: '+ chav);
    
    if(colc || chav){
        
        if(spl.length>1){
            
            var last1 = spl[spl.length-1];
            var last2 = spl[spl.length-2];

            //print('1: '+last1);
            //print('2: '+last2);
            if(chav){
                if(last2.match(/[A-Z]/i) && last1.match(/[A-Z]/i)){
                    ativarTeclado('bt_chaveFecha');
                    return false;
                }else{
                    ativarTeclado('');
                    return false;
                }
            }

            if(colc){
                //print('colc: '+last2);
                if(last1.match(/[A-Z]/i) || last1 == '}'){
                    if(!chav){
                        ativarTeclado('bt_chaveAbre, bt_colcheteFecha');
                        return false;
                    }
                }else{
                    if(!chav){
                        ativarTeclado('bt_chaveAbre');
                        return false;
                    }else{
                        ativarTeclado('');
                        return false;
                    }
                }
            }
            
        }else{
            
            
            if(colc){
                print('colc: '+colc);
                ativarTeclado('bt_chaveAbre');
                return false;
                
            }else if(chav){
                print('chav: '+chav);
                ativarTeclado('');
                return false;
            }else{
                print('else');
                ativarTeclado('bt_chaveAbre, bt_colcheteAbre');
                return false;
            }
            
        }
        
    }else{
        ativarTeclado('bt_chaveAbre, bt_colcheteAbre');
    }
    
    return true;
}

function ativarTeclado(botoes){
    
    // Desativa tudo
    desativarTeclado();
    
    if(botoes != ''){
        var i = 0;
        var bts = botoes.split(',');
        var qt  = bts.length;
        for(i=0; i<qt; i++){

            var botao = $.trim(bts[i]);
            print('botao -> '+botao);
            $('#teclado_tools .'+botao).prop('disabled', false);

        }
    }
    
}
function desativarTeclado(){
    $('#teclado_tools button').prop('disabled', true);
}

/*
function abreColchete(){
    colcheteAberto = true;
    ativarTeclado('bt_chaveAbre');
    letra = 0;
    
    print('abreColchete colcheteAberto: '+colcheteAberto);
    print('abreColchete chaveAberto: '+chaveAberto);
    print('abreColchete letra: '+letra);
    print('//////////////////');
}
function fechaColchete(){
    colcheteAberto = false;
    ativarTeclado('bt_chaveAbre, bt_colcheteAbre');
    
    print('fechaColchete colcheteAberto: '+colcheteAberto);
    print('fechaColchete chaveAberto: '+chaveAberto);
    print('fechaColchete letra: '+letra);
    print('//////////////////');
}
function abreChave(){
    chaveAberto = true;
    ativarTeclado('');
    letra = 0;
    
    print('abreChave colcheteAberto: '+colcheteAberto);
    print('abreChave chaveAberto: '+chaveAberto);
    print('abreChave letra: '+letra);
    print('//////////////////');
}
function fechaChave(){
    chaveAberto = false;
    
    if(!colcheteAberto){
        ativarTeclado('bt_chaveAbre, bt_colcheteAbre');
    }else if(colcheteAberto){
        ativarTeclado('bt_chaveAbre, bt_colcheteFecha');
    }else{
        ativarTeclado('bt_chaveAbre');
    }
    
    print('fechaChave colcheteAberto: '+colcheteAberto);
    print('fechaChave chaveAberto: '+chaveAberto);
    print('fechaChave letra: '+letra);
    print('//////////////////');
}
function addLetra(){
    plusLetra();
    
    if(chaveAberto){
        if(letra>1){
            ativarTeclado('bt_chaveFecha');
            letra = 0;
        }
    }
    if(colcheteAberto && !chaveAberto){
        ativarTeclado('bt_chaveAbre, bt_colcheteFecha');   
    }
    
    print('addLetra colcheteAberto: '+colcheteAberto);
    print('addLetra chaveAberto: '+chaveAberto);
    print('addLetra letra: '+letra);
    print('//////////////////');
}
function plusLetra(){
    letra = letra+1;
}
*/






function getPaineis(){
    
    $('#main .main_content').load('content/configuracoes-paineis.html', function(){
        
        $('#bt_cnf_agencia').click(function(e){
            e.preventDefault();

            getAgencia();
        });
        
        $('#bt_cnf_usuarios').click(function(e){
            e.preventDefault();

            getUsuarios();
        });

        $('#bt_cnf_categorias').click(function(e){
            e.preventDefault();

            getCategorias();
        });
        
        $('#bt_cnf_terminais').click(function(e){
            e.preventDefault();

            getTerminais();
        });
        
        $('#bt_cnf_paineis').click(function(e){
            e.preventDefault();

            getPaineis();
        });
        
        var formData = {};

        $.ajax({
            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url			: UTIL+'buscaPaineis'+suffix, // the url where we want to POST
            contentType : 'application/json',
            data		: JSON.stringify(formData), // our data object
            dataType	: 'json', // what type of data do we expect back from the server
            encode		: true
        }).done(function(data) {
            
            var linhas = "";
            print(data);
            if (data.display.length > 0) {
                for(var i=0; i<data.display.length; i++){

                    var painel      = data.display[i];
                    var status      = painel.isAtivo ? 'Sim' : 'Não';
                    var _hostname   = ((painel.hostname != '') && (painel.hostname != undefined)) ? painel.hostname : 'N/A';
                    var _macAddress = ((painel.macAddress != '') && (painel.macAddress != undefined)) ? painel.macAddress : 'N/A';

                    linhas += "<tr><td class='align_left'>"+painel.id+"</td><td>"+_hostname+"</td><td>"+_macAddress+"</td><td>"+status+"</td><td><a class='edit' data-data='"+JSON.stringify(painel)+"' href=''><i class='fas fa-edit'></i></a></td></tr>";

                }
            }
            $('#cnf_lista_paineis tbody').html(linhas);
            
            $('.edit').click(function(e){
                e.preventDefault();
                
                print('opa');
                
                var data    = $(this).data('data');
                
                $('.modal .modal_content').load('modal/crud-paineis.html', function(){
        
                    var setDisplay = data.tipoDisplay;
                    var listaTipoDisplay = '';
                    $.ajax({
                        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url			: UTIL+'buscaTipoDisplay'+suffix, // the url where we want to POST
                        contentType : 'application/json',
                        data		: '', // our data object
                        dataType	: 'json', // what type of data do we expect back from the server
                        encode		: true
                    }).done(function(data) {

                        print('data: '+data);
                        
                        for(var p = 0; p<data.tipoDisplay.length; p++){

                            var display = data.tipoDisplay[p];
                            listaTipoDisplay += '<option value="'+display.id+'">'+display.descricao+'</option>';

                        }
                        $('#tipoDisplay').html(listaTipoDisplay);
                        $('#tipoDisplay').val(setDisplay);
                        
                    });
                    
                    // Varre data para popular campos para edição
                    if (typeof data != undefined) {
                        $.each(data, function(k, v) {
                            
                            $('#'+k).val(v.toString());
                            
                        });
                    }
                    
                    if($('#hostname').val().length>=1){
                        $('#macAddress').prop("disabled", true);
                    }else if($('#macAddress').val().length>=1){
                        $('#hostname').prop("disabled", true);
                    }
                    
                    $('#hostname').keyup(function(){
                        var len = $(this).val().length;
                        if (len >= 1) {
                            $('#macAddress').prop("disabled", true);
                        }else{
                            $('#macAddress').prop("disabled", false);
                        }
                    });
                    
                    $('#macAddress').keyup(function(){
                        var len = $(this).val().length;
                        if (len >= 1) {
                            $('#hostname').prop("disabled", true);
                        }else{
                            $('#hostname').prop("disabled", false);
                        }
                    });

                    $('#cancelar').click(function(e){
                        e.preventDefault();

                        closeModal();
                    });

                    $('form').submit(function(e){
                        e.preventDefault();
                        
                        var formData = {
                            "hostname"              : $('#hostname').val(),
                            "idPainel"              : $('#id').val(),
                            "macAddress"            : $('#macAddress').val(),
                            "flgHabilitado"         : $('#isAtivo option:selected').val(),
                            "tipoDisplay"           : $('#tipoDisplay option:selected').val(),
                            "usuarioResponsavelId"  : currentUser.usuarioID
                        };

                        //print(formData);
                        $.ajax({
                            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                            url			: UTIL+'crudPainel'+suffix, // the url where we want to POST
                            contentType : 'application/json',
                            data		: JSON.stringify(formData), // our data object
                            dataType	: 'json', // what type of data do we expect back from the server
                            encode		: true
                        }).done(function(data) {

                            if(data.status == true){

                                closeModal();
                                getPaineis();

                            }else{
                                showMessage(data.msg);
                            }

                        }); 
                    });

                }, $('.modal').fadeIn());
                
            });
            
            $('.add_btn a').click(function(e){
                e.preventDefault();
                
                $('.modal .modal_content').load('modal/crud-paineis.html', function(){

                    var listaTipoDisplay = '';
                    $.ajax({
                        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url			: UTIL+'buscaTipoDisplay'+suffix, // the url where we want to POST
                        contentType : 'application/json',
                        data		: '', // our data object
                        dataType	: 'json', // what type of data do we expect back from the server
                        encode		: true
                    }).done(function(data) {

                        print('data: '+data);
                        
                        for(var p = 0; p<data.tipoDisplay.length; p++){

                            var display = data.tipoDisplay[p];
                            listaTipoDisplay += '<option value="'+display.id+'">'+display.descricao+'</option>';

                        }
                        $('#tipoDisplay').html(listaTipoDisplay);
                        
                    });
                    
                    $('#hostname').keyup(function(){
                        var len = $(this).val().length;
                        if (len >= 1) {
                            $('#macAddress').prop("disabled", true);
                        }else{
                            $('#macAddress').prop("disabled", false);
                        }
                    });
                    
                    $('#macAddress').keyup(function(){
                        var len = $(this).val().length;
                        if (len >= 1) {
                            $('#hostname').prop("disabled", true);
                        }else{
                            $('#hostname').prop("disabled", false);
                        }
                    });
                    
                    $('#cancelar').click(function(e){
                        e.preventDefault();

                        closeModal();
                    });

                    $('form').submit(function(e){
                        e.preventDefault();

                        var formData = {
                            "hostname"              : $('#hostname').val(),
                            "idPainel"              : $('#id').val(),
                            "macAddress"            : $('#macAddress').val(),
                            "flgHabilitado"         : $('#isAtivo option:selected').val(),
                            "tipoDisplay"           : $('#tipoDisplay option:selected').val(),
                            "usuarioResponsavelId"  : currentUser.usuarioID
                        };

                        print(formData);
                        $.ajax({
                            type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                            url			: UTIL+'crudPainel'+suffix, // the url where we want to POST
                            contentType : 'application/json',
                            data		: JSON.stringify(formData), // our data object
                            dataType	: 'json', // what type of data do we expect back from the server
                            encode		: true
                        }).done(function(data) {

                            if(data.status == true){

                                closeModal();
                                getPaineis();

                            }else{
                                showMessage(data.msg);
                            }

                        }); 
                    });

                }, $('.modal').fadeIn());
                
            });
            
        });
        
    });
    
}

function atendimentoChamarVoz(){
    if(usaLocucao == 'N'){
        usaLocucao = 'S';
        print('Voz');
        $('#bt_chamar_voz').html('<img src="assets/img/microfone-som.png" alt="">');
    }else{
        usaLocucao = 'N';
        print('Mudo');
        $('#bt_chamar_voz').html('<img src="assets/img/microfone-mudo.png" alt="">');
    }
}

/*function atendimentoNovaSenha(){

    var formData = {
        "btn"           : 676,
        "categoriaId"   : 676,
        "token"         : currentUser.emissorToken
    };
    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: ATENDIMENTO+'novaSenha'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {

        if(data){
            
            $('.info_chamada .n_atendimento_value').html(data.idAtendimento);
            $('.info_chamada .senha_value').html(data.senha);
            $('.info_chamada .categoria_value').html(data.nomeCategoria);
            $('.info_chamada .data_value').html(data.dtImpressao);

            ativar('bt_chamar_voz, bt_urgencia, bt_rechamar, bt_iniciar_atendimento, bt_cancelar');
            
            $('.info_chamada .info_content').slideToggle();
            
        }

    });
}*/

function atendimentoChamar(){

    desativar();
    
    var formData = {
        "idUsuario"         : currentUser.usuarioID,
        "token"             : currentUser.emissorToken,
        "usaLocucao"        : usaLocucao
    };
    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: ATENDIMENTO+'chamarSenha'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {

        print(data);
        if(data.idAtendimento != undefined){
            lastAction = 'chamar';
            
            emAtendimento   = true;
            idAtendimento   = data.idAtendimento;

            $('.info_chamada .n_atendimento_value').html(data.idAtendimento);
            $('.info_chamada .senha_value').html(data.senha);
            $('.info_chamada .data_value').html(data.dtImpressao);
            $('.info_chamada .categoria_value').html(data.nomeCategoria);
            
            if(data.crm.nome_cliente != ''){
                $('.info_chamada .telefone_value').html(data.crm.nome_cliente);
                $('.info_chamada .telefone').fadeIn();
            }
            if(data.tipoFilaRedirecionamento == true){
                $('.info_chamada .senha_redirecionada').fadeIn();
            }
            if(data.flgPriorizada == true){
                $('.info_chamada .senha_priorizada').fadeIn();
            }
            
            senhaAtual = data.senha;

            ativar('bt_chamar_voz, bt_rechamar, bt_iniciar_atendimento, bt_cancelar');
            
            print('--->>> atendimentoChamar - bt_rechamar');

            $('.info_chamada .info_content').slideDown();
            
        }else{
            showMessage(data.status);
        }

    });
}

function atendimentoReChamar(){
    
    ativar('');
    
    var formData = {
        "idUsuario"         : currentUser.usuarioID,
        "token"             : currentUser.emissorToken,
        "idAtendimento"     : idAtendimento,
        'usaLocucao'        : usaLocucao
    };
    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: ATENDIMENTO+'rechamarSenha'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {

        print(data);
        if(data.idAtendimento>0){
            lastAction = 'rechamar';
            desativaRechamar();
            
        }

    });
    
}
function atendimentoIniciarAtendimento(){
    
    var formData = {
        'idUsuario'         : currentUser.usuarioID,
        'token'             : currentUser.emissorToken,
        'idAtendimento'     : idAtendimento
    };
    
    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: ATENDIMENTO+'inicioAtendimento'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {

        if(data.idAtendimento>0){
            
            lastAction = 'iniciar_atendimento';
            
            catAtendimento  = data.categoria;
            
            contagemAtendimentoStart();
            
            ativar('bt_redirecionar, bt_finalizar');
            
            $('.info_inicio .date_call_value').html(data.dtChamada);
            $('.info_inicio .date_init_value').html(data.dtInicioAtendimento);
            $('.info_inicio .wait_value').html(data.tme);          
            
            var observacao = 'Nenhuma observação para este atendimento';
            if(data.obs !== ''){
                observacao = data.obs;
            }
            
            $('.info_obs .obs_value').html(observacao);
            
            $('.info_inicio').fadeIn();
            $('.info_obs').fadeIn();
            
            $('.box_info_atendimento').click(function(){
                $('.box_info_atendimento .info_content').slideUp();
                $(this).find('.info_content').slideToggle();
            });
            
            contagemBuscaStop();
            
        }

    });
    
}


function formatatempo(segs) {
    var min = 0;
    var hr  = 0;
    while(segs>=60) {
        if (segs >=60) {
            segs = segs-60;
            min = min+1;
        }
    }
    while(min>=60) {
        if (min >=60) {
            min = min-60;
            hr = hr+1;
        }
    }

    if (hr < 10) {hr = "0"+hr}
    if (min < 10) {min = "0"+min}
    if (segs < 10) {segs = "0"+segs}
    var fin = hr+":"+min+":"+segs
    return fin;
}
function contagem(){
    segsAtend++;
    var t = formatatempo(segsAtend);
    $("#timer").html(t);
}
function contagemAtendimentoStart(){
    contadorAtendimento = setInterval(contagem, 1000);
}
function contagemAtendimentoStop(){
    segsAtend = 0;
    $("#timer").html('00:00:00');
    clearInterval(contadorAtendimento);
}

function promptRedirecionar(){
    
    var formData = {};
    
    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: UTIL+'buscaCategorias'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {
        
        print(data);
        if(data.categoria!=''){
            openModalRedirecionar(data);
        }
        
    });
    
}

function atendimentoCancelar(){
    
    lastAction = 'cancelar';
    
    desativar();
    var formData = {
        'idUsuario'         : currentUser.usuarioID,
        'token'             : currentUser.emissorToken,
        'idAtendimento'     : idAtendimento
    };
    
    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: ATENDIMENTO+'cancelarSenha'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {

        //print('opa 2');
        //print(data);
        
        if(data.retorno == true){
            
            loadAtendimento();
            
            $('#bt_cancelar').css({'display':'none'});
            $('#bt_descancelar').css({'display':'block'});            
            
            setTimeout(function(){
                ativar('bt_chamar_voz, bt_chamar, bt_descancelar, bt_suspender');
            }, 100);
            
        }
        
    });
    
}

function atendimentoDescancelar(){
    
    var formData = {
        'idUsuario'         : currentUser.usuarioID,
        'idAtendimento'     : idAtendimento,
        'token'             : currentUser.emissorToken
    };
    
    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: ATENDIMENTO+'descancelarSenha'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {
        
		if(data.idAtendimento>0){
            
            print(data);
            
            lastAction = 'descancelar';
    
            emAtendimento   = true;
            idAtendimento   = data.idAtendimento;
    
            $('.info_chamada .n_atendimento_value').html(data.idAtendimento);
            $('.info_chamada .senha_value').html(data.senha);
            $('.info_chamada .categoria_value').html(data.nomeCategoria);
            $('.info_chamada .data_value').html(data.dtImpressao);

            ativar('bt_chamar_voz, bt_rechamar, bt_iniciar_atendimento, bt_cancelar');
            print('--- >>> atendimentoDescancelar - bt_rechamar');

            $('.info_chamada .info_content').slideDown();
            
        }
		
    });

}

function atendimentoFinalizar(){
    
    var formData = {};
    
    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: UTIL+'buscaObjetivo'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {

        if(data.objetivo!=''){
            openModalFinalizar(data);
        }
        
    });
    
}
function atendimentoSuspender(){
    
    var formData = {};
    
    $.ajax({
        type		: 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url			: UTIL+'buscaMotivoSuspensao'+suffix, // the url where we want to POST
        contentType : 'application/json',
        data		: JSON.stringify(formData), // our data object
        dataType	: 'json', // what type of data do we expect back from the server
        encode		: true
    }).done(function(data) {
        
        if(data.motivoSuspensao!==''){
            openModalSuspender(data);
        }
        
    });
    
}

function print(data){
    
    if(msieversion==true){
        $('#console').html(JSON.stringify(data));
    }else{
        console.log(data);
    }
    
}


function isNumberKey(evt){
     var charCode = (evt.which) ? evt.which : event.keyCode
     if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
     return true;
}

function msieversion() {

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)){
        return true;
        
    }else{
        return false;
        
    }

}